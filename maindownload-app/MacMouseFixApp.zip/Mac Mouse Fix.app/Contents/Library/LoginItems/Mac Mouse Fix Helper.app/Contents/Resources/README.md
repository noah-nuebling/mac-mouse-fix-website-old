CGSInternal
===========

A collection of private CoreGraphics routines.

